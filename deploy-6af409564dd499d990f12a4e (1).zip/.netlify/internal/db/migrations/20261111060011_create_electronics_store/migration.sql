CREATE TABLE "attempts" (
	"id" text PRIMARY KEY,
	"count" integer NOT NULL,
	"expires" timestamp NOT NULL
);
--> statement-breakpoint
CREATE TABLE "orders" (
	"id" text PRIMARY KEY,
	"access" text NOT NULL,
	"name" text NOT NULL,
	"phone" text NOT NULL,
	"email" text NOT NULL,
	"address" text NOT NULL,
	"items" jsonb NOT NULL,
	"total" integer NOT NULL,
	"utr" text NOT NULL UNIQUE,
	"status" text DEFAULT 'Payment review' NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" text PRIMARY KEY,
	"title" text NOT NULL,
	"category" text NOT NULL,
	"price" integer NOT NULL,
	"description" text NOT NULL,
	"image" text NOT NULL,
	"badge" text DEFAULT '' NOT NULL,
	"delivery" text DEFAULT '' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"id" text PRIMARY KEY,
	"expires" timestamp NOT NULL
);
--> statement-breakpoint
CREATE TABLE "settings" (
	"id" text PRIMARY KEY,
	"value" jsonb NOT NULL
);
--> statement-breakpoint
CREATE TABLE "tickets" (
	"id" text PRIMARY KEY,
	"name" text NOT NULL,
	"contact" text NOT NULL,
	"type" text NOT NULL,
	"order_id" text NOT NULL,
	"message" text NOT NULL,
	"status" text DEFAULT 'Open' NOT NULL,
	"created_at" timestamp DEFAULT now()
);
